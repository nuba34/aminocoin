from os import system as Z
#from keep_alive import keep_alive
Z("/opt/virtualenvs/python3/bin/python3 -m pip install --upgrade pip")
#keep_alive()
Z("clear")
Z("python coins.py")